# ansible-setup-docker
Docker compose for running Codebox Web IDE and ansible.


Create a Mount directory in docker host for Workspace 

   -  /mnt/codebox

Run the Docker Compose
 
   - docker-compose up -d

Access Credentials

   - http://ip

   - username: admin
   - password: standard_ic_pass
